package MyPkg;

class employee
{
	private int EmpID;
	private String EmpName;
	private double salary;
	
	//Short cut for getter setter is alt+shift+S
	public int getEmpID() {
		return EmpID;
	}
	public void setEmpID(int empID) {
		EmpID = empID;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public void displaydetails()
	{
		System.out.println("empID is "+EmpID);
		System.out.println("empName is "+EmpName);
		System.out.println("Salary is "+salary);	
	}
	
	
}

public class EncapsulationGetterSetter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		employee emp= new employee();
		emp.setEmpID(201308206);
		emp.setEmpName("Lavina Chahra");
		emp.setSalary(30000);
		emp.displaydetails();

	}

}
