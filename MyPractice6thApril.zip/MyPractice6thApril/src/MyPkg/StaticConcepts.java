package MyPkg;

class University
{
	static String country="India";
	public String UniName;
	
	University(String Uname)
	{
		
		this.UniName=Uname;
	
	}
	
}

public class StaticConcepts {

	public static void main(String[] args) 
	{
		System.out.println("Country name is "+University.country);
		University u1= new University("IIT");
		System.out.println("University name is "+u1.UniName);
	}

}
