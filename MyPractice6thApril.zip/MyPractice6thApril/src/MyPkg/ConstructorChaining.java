package MyPkg;

class Mall
{
	
	Mall()
	{
		System.out.println("Welcome to the Mall");
	}
	
	Mall(String Mname)
	{
		
		this();
		System.out.println(Mname);
		
	}
}

public class ConstructorChaining {

	public static void main(String[] args) 
	{
		new Mall();

        System.out.println();

        new Mall("Central City Mall");


	}

}
