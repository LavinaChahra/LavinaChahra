package MyPkg;

class school1
{
	public String name;
	public String address;
	public int strength;
	school1(String name, String address)
	{
		this.name=name;
		this.address=address;
	}
	
	school1(String name, String address, int strength)
	{
		this.name=name;
		this.address=address;
		this.strength=strength;
	}
	void display()
	{
		System.out.println("The name of school is "+name);
		System.out.println("The address of school is "+address);
		System.out.println("The strength of school is "+strength);
		
	}	
}

public class WAPinJava3 {

	public static void main(String[] args) 
	{
		school1 s1=new school1("GGIS","Bavdhan");
		s1.display();
		school1 s2=new school1("GGIS","Bavdhan",800);
		s2.display();
		
	}

}
