package MyPkg;

abstract class Animal
{
	abstract void sound();
	
}

class Dog extends Animal
{
	void sound()
	{
		System.out.println("Woof!!");
	}
}

class Cat extends Animal
{
	void sound()
	{
		System.out.println("Meow!");
	}
}

public class AbstractionusingAbstractClass {

	public static void main(String[] args) 
	{
		Dog d1=new Dog();
		d1.sound();
		Cat c1= new Cat();
		c1.sound();
		
		

	}

}
