package MyPkg;

class school
{
	public String name="GGIS";
	school()
	{
		System.out.println("The School name is "+name);
	}
	
	void displayschoolcity()
	{
		System.out.println("This School is based out of Pune");
	}
}


public class WAPinJava2 {

	public static void main(String[] args) 
	{
		school s1= new school();
		s1.displayschoolcity();

	}

}
