package MyPkg;

//Abstract class
abstract class BaseEmployee
{
	 String name;
	 int id;
	
	 // Constructor
	 BaseEmployee(String name, int id) 
	 {
	     this.name = name;
	     this.id = id;
	 }

	 // Abstract method
	 abstract double calculateSalary();

	 // Concrete method
	 void employeeDetails() 
	 {
     System.out.println("Employee Name: " + name);
     System.out.println("Employee ID: " + id);
	 }
}

//Subclass for Full-Time Employee
class FullTimeEmployee extends BaseEmployee 
{
	 double monthlySalary;
	//constructor
	 FullTimeEmployee(String name, int id, double monthlySalary) 
	 {
	     super(name, id);
		 
	     this.monthlySalary = monthlySalary;
	 }
	
	 @Override
	 double calculateSalary() 
	 {
	     // Full-time employees get a fixed monthly salary
	     return monthlySalary;
	 }
}

//Subclass for Part-Time Employee
class PartTimeEmployee extends BaseEmployee 
{
	 double hourlyRate;
	 int hoursWorked;
	//constructor
	 PartTimeEmployee(String name, int id, double hourlyRate, int hoursWorked) 
	 {
	     super(name, id);
	     this.hourlyRate = hourlyRate;
	     this.hoursWorked = hoursWorked;
	 }
	
	 @Override
	 double calculateSalary() 
	 {
	     // Part-time employees are paid based on hours worked
	     return hourlyRate * hoursWorked;
	 }
}

//Main class to test
public class AbstractclassandRealusage{
 public static void main(String[] args) {
     FullTimeEmployee fte = new FullTimeEmployee("Alice", 101, 50000);
     PartTimeEmployee pte = new PartTimeEmployee("Bob", 102, 500, 80);

     fte.employeeDetails();
     System.out.println("Salary: " + fte.calculateSalary());

     System.out.println();

     pte.employeeDetails();
     System.out.println("Salary: " + pte.calculateSalary());
 }
}