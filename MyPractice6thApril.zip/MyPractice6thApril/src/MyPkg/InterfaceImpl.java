package MyPkg;

interface Payment
{
	void makepayment();
}

class Upi implements Payment
{
	public void makepayment()
	{
		System.out.println("Your payment is made through UPI");
	}
}

class Creditcard implements Payment
{
	public void makepayment()
	{
		System.out.println("Your payment is made through CC");
	}
}

public class InterfaceImpl {

	public static void main(String[] args) 
	{
		Payment P1=new Upi();
		P1.makepayment();
		Payment P2=new Creditcard();
		P2.makepayment();

	}

}
