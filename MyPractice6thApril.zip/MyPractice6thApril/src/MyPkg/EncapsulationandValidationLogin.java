package MyPkg;

class Account
{
	private String Accountholdername;
	private int Balance;
	
	public String getAccountholdername() 
	{
		return Accountholdername;
	}
	public void setAccountholdername(String accountholdername) 
	{
		Accountholdername = accountholdername;
	}
	public int getBalance() 
	{
		return Balance;
	}
	public void setBalance(int balance) 
	{
		Balance = balance;
		if(Balance<0)
		{
			System.out.println("Balance is low!!! Hurry");
		}
	}
	
	public void display()
	{
		System.out.println("The Account HolderName is "+Accountholdername);
		System.out.println("The Balance is "+Balance);
	}
	
	
}


public class EncapsulationandValidationLogin {

	public static void main(String[] args) 
	{
		
		Account A1=new Account();
		A1.setAccountholdername("Lavina");
		A1.setBalance(-3000);
		A1.display();
	}

}
