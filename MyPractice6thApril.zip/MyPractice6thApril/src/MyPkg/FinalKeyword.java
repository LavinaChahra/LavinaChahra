package MyPkg;

class Bank
{
	//final int IFSC;
	//final void ShowIfsc()
	{
		System.out.println("final show");
	}
	
}

class HDFCBank extends Bank
{
	void ShowIfsc()
	{
		System.out.println("extended show");
	}
}
public class FinalKeyword {

	public static void main(String[] args) 
	{
		HDFCBank b1=new HDFCBank();
		b1.ShowIfsc();

	}

}
