package MyPkg;

class Student
{
	static String collegename="Sandip";
	String Name;
	int Rollno;
	
	void displayvariable()
	{
		System.out.println("the values are "+collegename+Name+Rollno);
		
	}
	Student(String Cname, String name, int Rno)
	{
		this.Name=name;
		collegename=Cname;
		this.Rollno=Rno;
	}
	
}

public class StaticKeyword {

	public static void main(String[] args) 
	{
		Student s1 = new Student("Medicaps", "Lokesh", 23);
        s1.displayvariable();

        Student s2 = new Student("IIT", "Rahul", 45);
        s2.displayvariable();
	}

}
