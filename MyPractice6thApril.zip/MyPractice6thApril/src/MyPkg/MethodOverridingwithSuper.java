package MyPkg;

class Hospital
{
	public void EmergService()
	{
		System.out.println("Parent hospital service");
	}
}

class CityHospital extends Hospital
{
	public void EmergService()
	{
		super.EmergService();
		System.out.println("City hospital service");
	}
}

public class MethodOverridingwithSuper {

	public static void main(String[] args) 
	{
		CityHospital ch=new CityHospital();
		ch.EmergService();

	}

}
