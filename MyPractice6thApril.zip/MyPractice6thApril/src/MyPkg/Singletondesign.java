package MyPkg;

public class SingletonDesign {

	

	private static SingletonDesign object;

	

	private static SingletonDesign getInstance() {

		if(object == null) {

			object = new SingletonDesign();

		}

		return object;

	}

	public void display() {

		System.out.println("Display Method");

		System.out.println(object.hashCode());

	}

	public static void main(String[] args) {

		SingletonDesign s1	= new SingletonDesign().getInstance();

		s1.display();//s1 = 1159190947;

		

		SingletonDesign s2 = new SingletonDesign().getInstance();

		System.out.println(s2.hashCode());

	}

}