package MyPkg;

class ShapeIS
{
	public double length;
	ShapeIS(double length)
	{
		this.length=length;
	}
	public double square()
	{
		double area;
		area=length*length;
		return area;
		
	}
	public double rectangle(int width)
	{
		double area;
		area=length*width;
		return area;
	}
	public double circle(int radius)
	{
		double area;
		area=Math.PI*radius*radius;
		return area;
	}
}

public class WAPinJava1 {

	public static void main(String[] args) 
	{
		ShapeIS s1=new ShapeIS(5);
		System.out.println("The area of square is " +s1.square());
		System.out.println("The area of rectangle is " +s1.rectangle(7));
		System.out.println("The area of circle is " +s1.circle(3));
		

	}

}
