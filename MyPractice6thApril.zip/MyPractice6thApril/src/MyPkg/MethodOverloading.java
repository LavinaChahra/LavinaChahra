package MyPkg;

class Calculator
{
	public int add()
	{
		int a=10;
		int b=15;
		return a+b;
		
	}
	
	public int add(int a, int b)
	{
		return a+b;
	}
	
	public double add(double a, double b)
	{
		return a+b;
	}
}

public class MethodOverloading {
	
	public static void main(String[] args) 
	{
		Calculator c1=new Calculator();
		System.out.println(c1.add());
		System.out.println(c1.add(25,30));
		System.out.println(c1.add(12.3,13.9));
	}

}
