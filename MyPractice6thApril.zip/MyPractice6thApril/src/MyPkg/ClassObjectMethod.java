package MyPkg;


class Library
{
	String Libraryname;
	
	Library()
	{
		System.out.println("Welcome to the Library!");
	}
	
	void showlocation()
	{
		System.out.println("This library is located in Mumbai");
	}
}
public class ClassObjectMethod {

	public static void main(String[] args) 
	{
		Library L1=new Library();
		L1.showlocation();

	}

}
