package MyPkg;

public class InheritanceMethodOverriding {
	
	public class Vehicle
	{
		public void fueltype()
		{
			System.out.println("runs on fuel");
		}
	}
	
	public class Electriccar extends Vehicle
	{
		@Override
		public void fueltype()
		{
			System.out.println("Runs on electricity");
		}
	}

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

		InheritanceMethodOverriding I1=new InheritanceMethodOverriding();
		Vehicle v1=I1.new Vehicle();
		v1.fueltype();
		Electriccar e1 =I1.new Electriccar();
		e1.fueltype();
		
	}

}
