package MyPkg;

public class ConstructorOverloading {
	
	public class Product
	{
		private int productId;
		private String productName;
		private double price;
		
		Product()
		{
			System.out.println("Product created");
		}
		
		Product(int pid, String pname, double pp)
		{
			this.productId=pid;
			this.productName=pname;
			this.price=pp;
		}
		
		public void displayproduct()
		{
			System.out.println("The productId is "+productId);
			System.out.println("The product name is "+productName);
			System.out.println("The product price is "+price);
			
		}
	}

	public static void main(String[] args) 
	{
		ConstructorOverloading co1= new ConstructorOverloading();
		Product p1= co1.new Product(23,"Lavina",35.6);
		p1.displayproduct();
	}

}
