package MyPkg;

class GovernmentRules
{
	final int MAX_WORKING_HOURS = 8;
	
}

public class FinalKeywordConstant {

	public static void main(String[] args) 
	{
		GovernmentRules g1= new GovernmentRules();
		//g1.MAX_WORKING_HOURS= g1.MAX_WORKING_HOURS+5;
		System.out.println(g1.MAX_WORKING_HOURS);
	}

}
