package MyPkg;

class Camera
{
	public void capture()
	{
		System.out.println("Capture from camera");
	}
}

class dslcamera extends Camera
{
	//@override
	public void capture()
	{
		System.out.println("Capture from DSLCAmera");
	}
}

public class PolymorphismRuntimeUpcasting {

	public static void main(String[] args) 
	{
		Camera C1= new dslcamera();
		C1.capture();

	}

}
