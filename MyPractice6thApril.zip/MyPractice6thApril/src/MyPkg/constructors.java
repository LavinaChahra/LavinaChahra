package MyPkg;

class Employee
{
	String name;
	int id;
	
	//name
	
	public Employee(String name)
	{
		this(name, 0);	
	}
	
	public Employee(String name, int id)
	{
		this.name = name;
		this.id = id;
	}
	
	public void display()
	{
		System.out.println("Name and id is "+name +id);
	}
}

public class constructors {

	public static void main(String[] args) {
		Employee e1=new Employee("Lavina", 22);
		e1.display();
		Employee e2= new Employee("Sudha");
		e2.display();

	}

}
