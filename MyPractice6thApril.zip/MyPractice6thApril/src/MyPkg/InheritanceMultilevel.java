package MyPkg;

class Device
{
	public void start()
	{
		System.out.println("starting the device");
	}
}
class Mobile extends Device
{
	public void calling()
	{
		System.out.println("Calling from mobile");
	}
}

class smartphone extends Mobile
{
	public void internet()
	{
		System.out.println("Chatting through smartphone using Internet");
	}
}

public class InheritanceMultilevel {

	public static void main(String[] args) 
	{
		smartphone s1=new smartphone();
		s1.start();
		s1.calling();
		s1.internet();

	}

}
