package MyPkg;


interface transport
{
	void booking();
	
}

class Bus implements transport
{
	public void booking()
	{
		System.out.println("Busbooking");
	}
}

class flight implements transport
{
	public void booking()
	{
		System.out.println("flightbooking");
	}
}

public class InterfaceMultipleImplementation {

	public static void main(String[] args) 
	{
		transport t1=new Bus();
		t1.booking();
		transport t2= new flight();
		t2.booking();
		

	}

}
