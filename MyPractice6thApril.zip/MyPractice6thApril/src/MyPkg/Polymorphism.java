package MyPkg;

class Shape
{
	public void Area()
	{
		System.out.println("This is Shape Area");
	}
}

class Rectangle extends Shape
{
	public void Area()
	{
		System.out.println("this is rectangle area");
	}
}
class Circle extends Shape
{
	public void Area()
	{
		System.out.println("this is Circle area");
	}
}

public class Polymorphism {

	public static void main(String[] args) {
		
		Rectangle sh1= new Rectangle();
		sh1.Area();
		Circle sh2=new Circle();
		sh2.Area();
	}

}
