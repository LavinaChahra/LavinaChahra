package MyPkg;

class Loancalculator
{
	public void calculateloan(int amount)
	{
		System.out.println("the loan amt is "+amount);
	}
	
	public void calculateloan(int amount, double interestrate)
	{
		System.out.println("the calculated loan amt is "+amount*interestrate);
	}
}

public class Methodoverloadingpart2 {

	public static void main(String[] args) 
	{
		Loancalculator lc=new Loancalculator();
		lc.calculateloan(50000);
		lc.calculateloan(30000, 7.10);
	}

}
