package MyPkg;
class person
{
	person()
	{
		System.out.println("Person Created");
	}
}

class student extends person
{
	student()
	{
		super();
		System.out.println("Student created");
	}
	
	void display()
	{
		System.out.println("Super keyword execution");
	}
}

public class SuperKeyword {

	public static void main(String[] args) {
		
	student st1=new student();
	st1.display();
	
	}

}
