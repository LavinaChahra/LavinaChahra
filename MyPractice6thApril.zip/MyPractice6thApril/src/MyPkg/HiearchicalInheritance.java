package MyPkg;

class Course
{
	public void Courseinfo()
	{
		
	}
}
class science extends Course
{
	public void tech()
	{
		System.out.println("I am science student!");
	}
}

class commerce extends Course
{
	public void finance()
	{
		System.out.println("I am commerce student!");
	}
}
class arts extends Course
{
	public void History()
	{
		System.out.println("I am Arts student!");
	}
}
public class HiearchicalInheritance {

	public static void main(String[] args) 
	{
		
		science s1= new science();
		s1.tech();
		commerce c1=new commerce();
		c1.finance();
		arts a1=new arts();
		a1.History();
		
	}

}
